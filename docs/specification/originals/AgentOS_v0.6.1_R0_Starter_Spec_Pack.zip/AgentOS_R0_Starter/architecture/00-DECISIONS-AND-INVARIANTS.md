# AgentOS Implementation Architecture — Decisions, Invariants and Provenance

**Version:** 0.6.1 implementation-spec pack, 2026-10-11. **Status:** implementation design, review required.  
**Normative baseline:** `../references/AgentOS_v0.6.1_Architecture_Baseline.md` (copied without modification).  
**Change control:** Freeze architectural principles; revise task specs and ADRs based on measured implementation results. Do not silently change the source baseline.

## Source-of-truth hierarchy
1. Explicit user/project safety requirements and approved architecture decisions.
2. The v0.6.1 master architecture (target capabilities and invariant constraints).
3. This package's versioned cross-component contracts; update through ADRs.
4. AOS-001–037 individual implementation specifications; each defines scope, acceptance and dependencies.
5. Actual implementation code/tests and observed hardware/provider behavior. When code diverges from a spec, file an ADR or defect; never quietly rewrite the spec to rationalize the code.

## Known implementation-asset caveat
The review reports an **existing Agent Skills bundle** containing `hardware-probe`, `claude-code-worker`, `verified-research-brief`, `egress-preflight`, `milestone-handoff`, `capture-learning`, and `goal-contract`. It also reports a tested `hwprobe.py` prototype on five simulated profiles. **Their actual source and test results were not attached to this session**, so this package does not assert they have been inspected or integrated. The first build plan must inventory actual files, hashes, tests, and licenses, then adopt/update rather than rebuilding. A status of `candidate-existing` is different from `integrated-and-tested`.

## Locked architecture invariants
- Kernel owns authoritative task, attempt, approval, policy, budget, side-effect and audit records. An LLM cannot authorize work.
- Goal-contract versions are immutable and acceptance checks must be executable, human-reviewed, or explicitly `unverifiable`; prose alone is not a passed check.
- **Trust** (project runtime certification), **privacy** (data sensitivity and allowed destinations), **autonomy** (action approval) are independently persisted and enforced; effective permission is their intersection with sandbox and provider scopes.
- Off-device work is opt-in and never a fallback for `RESTRICTED` content. Local model non-residency cannot stop deterministic kernel operations.
- Workers/harnesses and inference runtimes are replaceable; all status and artifacts remain platform-owned.
- Crash recovery does not imply exactly-once external effects. Unknown effects must enter `RECONCILING`, without automatic duplication.
- Repo files, skills, search results, MCP outputs and web text are untrusted. The isolation layer, not the prompt, enforces boundaries.
- Logs and accounting distinguish `known`, `estimated`, `unknown`; missing billing data is not zero.
- Every cloud report distinguishes `authorized`, `accessible`, and `observed` disclosures.
- Every implementation must have deterministic acceptance tests, failure tests, an owner-visible audit trail, and a rollback strategy.

## Platform stack policy
- Python 3.12+ managed by `uv`, FastAPI, SQLAlchemy 2 and Alembic, PostgreSQL; DBOS durable workflows. Versions pinned by lockfile after compatibility tests.
- `pytest`, Ruff, Mypy, Pydantic v2, testcontainers or ephemeral Postgres for integration. Tool suggestions are **proposed**, not claimed installed.
- Start with CLI + minimal loopback HTTP API, then introduce React/Vite and SSE. Observability uses OpenTelemetry and optionally local Phoenix. No mandatory SaaS.
- Ollama first, vLLM/SGLang benchmarked on actual hardware; AWS/cloud APIs and vendor CLI agents only through explicitly approved paths.
- No generic tool-installation or personal-data ingestion during the R0 synthetic proof.

## Release gates (change relative to frozen master)
- **R0 / Kernel Proof:** AOS-001–005, synthetic goal → durable mock worktree → verifier → approval, crash-tested, no real accounts or sensitive repo.
- **R1 / Personal Alpha:** Offline Ask + bounded Build using **one** hardened Claude Code worker; policy/sandbox gates AOS-006–012,014–018; minimal CLI/status UI. AOS-027 verifier/approval core is *pulled forward* in scoped form without changing its identity or presuming full R3 completion.
- **R2 / Research Alpha:** Read-only Delegate; AOS-013 and AOS-019–023; configurable search backend, network isolation, fetched-source provenance and support verification.
- **R3 / Multi-Agent Alpha:** AOS-024–030; Codex, two-worker scheduling, complete React Mission Control, Phoenix, full journey and chaos suite. AOS-027 completed in full here.
- **R4 / Intelligent Resources:** AOS-031–033 (Phase 2 capabilities).
- **R5 / Context & Desktop:** AOS-034–035 (Phase 3).
- **R6 / Evaluated Adaptation:** AOS-036 (Phase 4).
- **R7 / Open-Source Portability:** AOS-037 (Phase 5).

**R1 is not allowed to operate on real repositories/accounts until corresponding security gates pass**; R0 uses synthetic and mock resources. This release split is an implementation sequencing addendum, not a reduction of full SOTA requirements.

## New ADRs to be approved with implementation
- ADR-001: Adopt portable Agent Skills (`SKILL.md`) for procedural capabilities, plus separate AgentOS permission/IO manifest; skill validator and provenance gate.
- ADR-002: Approved search-provider interface: SearXNG and configurable commercial provider; each search is a network disclosure with stored telemetry; SearXNG itself may contact upstream engines.
- ADR-003: Public kernel API remains transport-agnostic so an opt-in MCP server can expose `submit_goal`, `get_status`, `get_artifacts`, `list_tasks` after R1. No MCP caller bypasses kernel policy; Hermes is one potential MCP client, not an OS-internal authority.
- ADR-004: Use DBOS initially with PostgreSQL, no promise of trivial Temporal substitution. Re-evaluate distributed executor only against actual multi-node needs.
- ADR-005: No brand selection on critical path; `agentos` is a **private codename**. Public name/CLI/PyPI/npm/GitHub/domain clearance before public beta.
- ADR-006: Explicit release ladder R0–R7. Every promotion is conditional on specified tests; no cross-project widening by trust-mode promotion.

## Build/plan-generation discipline
For each `AOS-NNN`, the implementation plan **must** name source files, migrations, integration points, tests, deployment operations, acceptance evidence and rollback. Distinguish existing code, source-backed fact, design proposal, and unresolved issue. No plan may infer that a skill or CLI flag works solely from this spec. Record the exact commit/SHA, runtime and vendor version that passed its acceptance suite.

## References
- Official DBOS durability and idempotency: https://docs.dbos.dev/python/tutorials/workflow-tutorial
- DBOS determinism, retries and recovery: https://docs.dbos.dev/architecture
- MCP tool specification (2026-07-28): https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/docs/specification/2026-07-28/server/tools.mdx
- Search API: https://docs.searxng.org/dev/search_api.html
- Agent Skills specification: https://agentskills.io/specification
- Claude CLI docs: https://code.claude.com/docs/en/cli-reference
- Anthropic security and compliance: https://code.claude.com/docs/en/legal-and-compliance
- OpenAI plan-use terms: https://openai.com/policies/sign-in-with-chatgpt-terms/
