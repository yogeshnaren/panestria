---
name: egress-preflight
description: Before any cloud model or vendor harness (Claude Code, Codex, Gemini CLI, Cursor) is given a workspace, list every file it could read with hashes and privacy labels, block never-send paths, secret-looking content, escaping symlinks and data above the destination's allowed class, and write a manifest for the cloud exposure ledger. Use before every cloud-bound job and when a user asks what an agent could see.
license: Apache-2.0
compatibility: Python 3.10+ (stdlib only). Linux or macOS.
metadata:
  author: agentos
  version: "0.1.0"
  stage: mvp
---

# Egress pre-flight

Vendor CLIs encrypt their own traffic, so nobody can prove exactly what they sent.
What can be controlled and recorded is what they could *read*. Treat everything in
the workspace, including hidden files and git history, as sendable.

## Steps

1. Know three things: the workspace path, the task's privacy class, and the
   destination (for example `anthropic`, `openai`, `local`).
2. Run the check against the user's policy (example in
   `assets/egress-policy.example.json`):
   ```bash
   python3 scripts/egress_manifest.py <workspace> --policy policy.json \
     --class internal --dest anthropic --out manifest.json
   ```
3. Exit code 0 means allowed. Attach `manifest.json` (its `manifest_sha256`) to the
   attempt record and the exposure ledger as the *accessible* evidence.
4. Exit code 1 means blocked. Show the user the `violations` list. Fix by removing
   the files from the workspace, choosing a local backend, or asking the user to
   change the policy. Never relabel data to a lower class on your own.

## What it blocks

- Paths matching `never_send` globs (absolute, `~`-relative or workspace-relative).
- Content matching secret patterns: private keys, cloud and API tokens.
- Symlinks that resolve outside the workspace.
- Files whose label (from `.agentos-labels.json` in the workspace, or the policy's
  `labels`) is stricter than what the destination may receive.
- Any destination not listed for the task's class.

## Notes

- `.git/` is included as one entry with its size: history is readable by the agent.
  Use a fresh shallow worktree when history is sensitive.
- The manifest records labels, hashes and sizes, never file contents.
- This is a pre-flight check, not the sandbox. The OS sandbox and network allowlist
  still enforce limits while the job runs.
