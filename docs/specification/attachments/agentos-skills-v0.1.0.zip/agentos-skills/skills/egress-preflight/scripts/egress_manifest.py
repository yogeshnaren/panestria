#!/usr/bin/env python3
"""List what a cloud-bound agent could read, and block what policy forbids.

Usage:
  python3 egress_manifest.py WORKSPACE --policy policy.json --class internal \
      --dest anthropic [--out manifest.json]
Exit 0 = allowed, 1 = blocked, 2 = usage/policy error. The manifest holds paths,
sizes, sha256 and labels, never file contents.
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import os
import re
import sys
import time

ORDER = ["public", "internal", "confidential", "restricted"]  # least to most sensitive
PATTERNS = {
    "private_key": re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY"),
    "aws_access_key": re.compile(rb"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"),
    "github_token": re.compile(rb"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36,}\b|github_pat_[A-Za-z0-9_]{40,}"),
    "slack_token": re.compile(rb"\bxox[abpors]-[A-Za-z0-9-]{10,}"),
    "generic_api_key": re.compile(
        rb"(?i)(?:api[_-]?key|secret|token|passwd|password)\s*[:=]\s*['\"][A-Za-z0-9_\-./+]{16,}['\"]"),
}


def matches(rel: str, full: str, globs: list[str]) -> str | None:
    home = os.path.expanduser("~")
    for g in globs:
        ge = os.path.expanduser(g)
        if fnmatch.fnmatch(full, ge) or fnmatch.fnmatch(rel, g) or fnmatch.fnmatch(rel, g.lstrip("*/")):
            return g
        if g.startswith("**/") and fnmatch.fnmatch(os.path.basename(rel), g[3:]):
            return g
        if ge.startswith(home) and fnmatch.fnmatch(full, ge):
            return g
    return None


def label_for(rel: str, labels: dict[str, str]) -> str | None:
    best = None
    for g, cls in labels.items():
        if fnmatch.fnmatch(rel, g) and (best is None or ORDER.index(cls) > ORDER.index(best)):
            best = cls
    return best


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("workspace")
    ap.add_argument("--policy", required=True)
    ap.add_argument("--class", dest="cls", required=True, choices=ORDER)
    ap.add_argument("--dest", required=True)
    ap.add_argument("--out")
    a = ap.parse_args()

    try:
        with open(a.policy, encoding="utf-8") as f:
            policy = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        print(f"cannot read policy: {e}", file=sys.stderr)
        sys.exit(2)
    root = os.path.realpath(a.workspace)
    labels = dict(policy.get("labels", {}))
    local_labels = os.path.join(root, ".agentos-labels.json")
    if os.path.exists(local_labels):
        with open(local_labels, encoding="utf-8") as f:
            labels.update(json.load(f))
    pats = {k: PATTERNS[k] for k in policy.get("deny_patterns", PATTERNS) if k in PATTERNS}
    max_bytes = int(policy.get("max_file_mb_scanned", 5) * 1024 * 1024)
    allowed_dests = policy.get("classes", {}).get(a.cls, {}).get("destinations", [])
    dest_rank = max((ORDER.index(c) for c, v in policy.get("classes", {}).items()
                     if a.dest in v.get("destinations", [])), default=-1)

    violations, files = [], []
    if a.dest not in allowed_dests:
        violations.append({"type": "destination_not_allowed", "detail": f"{a.dest} not allowed for {a.cls}"})

    for dirpath, dirnames, filenames in os.walk(root):
        if ".git" in dirnames:
            gitdir = os.path.join(dirpath, ".git")
            size = sum(os.path.getsize(os.path.join(d, x)) for d, _, fs in os.walk(gitdir) for x in fs
                       if not os.path.islink(os.path.join(d, x)))
            files.append({"path": os.path.relpath(gitdir, root), "kind": "git_history", "bytes": size})
            dirnames.remove(".git")
        for name in dirnames + filenames:
            full = os.path.join(dirpath, name)
            rel = os.path.relpath(full, root)
            if os.path.islink(full):
                target = os.path.realpath(full)
                if os.path.commonpath([root, target]) != root:
                    violations.append({"type": "escaping_symlink", "path": rel, "detail": target})
                    continue
            if name not in filenames:
                continue
            entry: dict = {"path": rel, "kind": "file", "bytes": os.path.getsize(full)}
            g = matches(rel, full, policy.get("never_send", []))
            if g:
                violations.append({"type": "never_send", "path": rel, "detail": g})
            lab = label_for(rel, labels)
            entry["label"] = lab or a.cls
            if lab and ORDER.index(lab) > max(ORDER.index(a.cls), dest_rank):
                violations.append({"type": "label_above_destination", "path": rel,
                                   "detail": f"{lab} data cannot go to {a.dest}"})
            h = hashlib.sha256()
            scanned = 0
            hits = set()
            with open(full, "rb") as f:
                while chunk := f.read(1 << 20):
                    h.update(chunk)
                    if scanned < max_bytes:
                        for k, p in pats.items():
                            if p.search(chunk):
                                hits.add(k)
                    scanned += len(chunk)
            entry["sha256"] = h.hexdigest()
            for k in sorted(hits):
                violations.append({"type": "secret_pattern", "path": rel, "detail": k})
            files.append(entry)

    body = {"workspace": root, "privacy_class": a.cls, "destination": a.dest,
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "files": sorted(files, key=lambda x: x["path"]), "violations": violations,
            "verdict": "blocked" if violations else "allowed"}
    body["manifest_sha256"] = hashlib.sha256(json.dumps(body["files"], sort_keys=True).encode()).hexdigest()
    text = json.dumps(body, indent=2)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(text)
    print(json.dumps({"verdict": body["verdict"], "files": len(files),
                      "violations": violations, "manifest_sha256": body["manifest_sha256"]}, indent=2))
    sys.exit(1 if violations else 0)


if __name__ == "__main__":
    main()
