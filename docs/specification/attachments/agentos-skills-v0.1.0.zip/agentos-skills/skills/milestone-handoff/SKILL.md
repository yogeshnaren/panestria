---
name: milestone-handoff
description: Keep long-running agent work on plan across sessions - a JSON feature list where workers may only flip a milestone to passing with evidence, a progress log, one commit per milestone, and a written handoff so a fresh session resumes without the old transcript. Use at the start and end of every session on a multi-session goal, and before declaring any milestone done.
license: Apache-2.0
compatibility: Python 3.10+ (stdlib only), git.
metadata:
  author: agentos
  version: "0.1.0"
  stage: mvp
---

# Milestone handoff

Pattern adapted from Anthropic's long-running agent harness: a full feature list
written up front, one milestone per session, a clean state at every session end.

## Files in the project root

- `features.json`: the milestones (template in `assets/features.template.json`).
  Written once by the planner from the goal contract; all start `"passes": false`.
- `PROGRESS.md`: append-only log, newest entry at the top.
- `HANDOFF.md`: overwritten at the end of each session (template in
  `assets/HANDOFF.template.md`).

## Session start

1. Read `HANDOFF.md`, the top of `PROGRESS.md` and `git log --oneline -15`.
2. Run the project's quick check (for example `./init.sh` or the test command in
   the goal contract) before changing anything. If it fails, fixing that comes first.
3. Pick exactly one milestone with `"passes": false` whose dependencies pass.

## During the session

- Work only on that milestone. Anything else you notice goes into `HANDOFF.md`
  under "Noticed, not done".
- Stay inside the goal contract's allowed paths and tools.

## Marking a milestone done

1. Run its acceptance check for real.
2. Copy `features.json` to `features.prev.json`, set `"passes": true`, and fill
   `evidence` (the command and its result, or the file path proving it).
3. Validate the change:
   ```bash
   python3 scripts/check_features.py features.prev.json features.json
   ```
   It fails if anything other than `passes`/`evidence` changed, if a milestone was
   added, removed or reworded, or if a milestone passed without evidence.
4. Commit with a message naming the milestone ID.

## Session end (always, even when stopping early)

1. Leave the code in a state that could be merged: tests pass, no half edits.
2. Append a dated entry to `PROGRESS.md`.
3. Overwrite `HANDOFF.md` from the template: what changed, what's next, blockers,
   exact commands to resume.

Changing milestones themselves (adding, removing, rewording) is a plan change:
it needs a new goal-contract version and user approval, never an in-session edit.
