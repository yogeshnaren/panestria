# Handoff — <goal id>, session <n>, <date>

## State
- Milestones passing: <k> of <total>
- Last commit: <hash> <message>
- Quick check: <command> → <pass/fail>

## Done this session
- <milestone id>: <one line>, evidence: <command/result>

## Next
- <milestone id> — <why it's next>

## Blockers and questions for the user
- <none, or the exact question>

## Noticed, not done
- <out-of-scope observations>

## Resume with
```bash
<exact commands to set up and continue>
```
