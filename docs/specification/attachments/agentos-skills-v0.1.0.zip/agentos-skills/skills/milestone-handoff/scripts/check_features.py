#!/usr/bin/env python3
"""Validate that a features.json change only marks milestones passing, with evidence.

Usage: python3 check_features.py features.prev.json features.json
Exit 0 if the change is legal, 1 if not.
"""
from __future__ import annotations

import json
import sys

MUTABLE = {"passes", "evidence"}


def load(p: str) -> dict:
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    old, new = load(sys.argv[1]), load(sys.argv[2])
    errors, notes = [], []
    for key in ("goal_id", "contract_version"):
        if old.get(key) != new.get(key):
            errors.append(f"{key} changed ({old.get(key)!r} -> {new.get(key)!r}); plan changes need a new contract version")
    o = {f["id"]: f for f in old.get("features", [])}
    n = {f["id"]: f for f in new.get("features", [])}
    for fid in o.keys() - n.keys():
        errors.append(f"milestone removed: {fid}")
    for fid in n.keys() - o.keys():
        errors.append(f"milestone added: {fid}")
    if [f["id"] for f in old.get("features", [])] != [f["id"] for f in new.get("features", []) if f["id"] in o]:
        errors.append("milestones were reordered")
    for fid in o.keys() & n.keys():
        a, b = o[fid], n[fid]
        for k in (set(a) | set(b)) - MUTABLE:
            if a.get(k) != b.get(k):
                errors.append(f"{fid}: field {k!r} changed; only passes/evidence may change")
        if not a.get("passes") and b.get("passes"):
            if not str(b.get("evidence") or "").strip():
                errors.append(f"{fid}: marked passing without evidence")
            unmet = [d for d in b.get("depends_on", []) if not n.get(d, {}).get("passes")]
            if unmet:
                errors.append(f"{fid}: marked passing while dependencies fail: {unmet}")
            notes.append(f"{fid}: now passing")
        if a.get("passes") and not b.get("passes"):
            notes.append(f"{fid}: REGRESSED (was passing); reopen and investigate")
    for x in notes:
        print(f"NOTE  {x}")
    for e in errors:
        print(f"ERROR {e}")
    if errors:
        print("ILLEGAL CHANGE")
        sys.exit(1)
    print("OK")


if __name__ == "__main__":
    main()
