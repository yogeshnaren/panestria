---
name: goal-contract
description: Turn a user's request into an approved goal contract - intended outcome, machine-checkable acceptance checks, constraints, allowed paths and tools, budget, non-goals and privacy class - before any agent starts work. Use for every Delegate or Build task, whenever scope is ambiguous, and whenever a plan change needs a new contract version.
license: Apache-2.0
compatibility: Python 3.10+. Validating YAML contracts needs PyYAML; JSON contracts need only the standard library.
metadata:
  author: agentos
  version: "0.1.0"
  stage: mvp
---

# Goal contract

A goal is not a prompt. Before work starts, write down what "done" means in a form
a machine can check, what is off limits, and what it may cost. Agents work toward
the contract; the verifier judges against it; the user approves it.

## Steps

1. Restate the request in one sentence as the `intent`.
2. Copy `assets/goal-contract.template.yaml` and fill it in:
   - `privacy_class`: restricted | confidential | internal | public. If unsure, pick
     the stricter class and ask the user.
   - `constraints.allowed_paths` and `forbidden_paths`: keep the default secret
     patterns in `forbidden_paths`.
   - `acceptance`: every item needs a `check` the verifier can run:
     `command` (exit code 0 passes), `file_exists`, `path_scope` (no edits outside
     allowed paths), `citations` (for research briefs), `rubric` (an independent
     model scores against examples) or `human_review`.
   - `budget`: dollars for API calls, maximum attempts, wall-clock minutes.
   - `non_goals`: things a reasonable agent might do that the user does not want.
3. Validate:
   ```bash
   python3 scripts/validate_contract.py contract.yaml
   ```
4. Show the user the contract in plain language and ask for approval when the task
   touches real files, spends money, sends anything externally or is large.
5. Never edit an approved contract in place. A scope change creates `version: N+1`
   with a `change_reason`, and needs approval again.

## Writing good acceptance checks

- Prefer deterministic checks (tests, file existence, scope) over rubrics.
- A rubric-only contract is acceptable only for subjective work, and must name the
  examples it is calibrated on.
- "Agent says it's done" is never a check.
- At least one check must fail before the work and pass after it; otherwise the
  contract proves nothing.

## Example

Request: "Add retry with backoff to the HTTP client and keep the public API stable."

- intent: Add bounded retry with exponential backoff to `src/http_client.py`.
- acceptance: `command: pytest -q tests/test_http_client.py`; `path_scope`;
  `human_review` before merge.
- non_goals: changing public function signatures; adding dependencies.
