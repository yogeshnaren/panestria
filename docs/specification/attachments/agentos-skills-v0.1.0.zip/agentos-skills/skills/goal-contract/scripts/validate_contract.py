#!/usr/bin/env python3
"""Validate a goal contract (YAML or JSON). Exit 0 if valid, 1 if not.

Usage: python3 validate_contract.py contract.yaml [--strict]
--strict also fails on warnings (for example a rubric-only contract).
"""
from __future__ import annotations

import json
import sys

PRIVACY = {"restricted", "confidential", "internal", "public"}
CHECK_TYPES = {"command", "file_exists", "path_scope", "citations", "rubric", "human_review"}
DETERMINISTIC = {"command", "file_exists", "path_scope", "citations"}
SECRET_DEFAULTS = [".env*"]


def load(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        text = f.read()
    if path.endswith(".json"):
        return json.loads(text)
    try:
        import yaml  # type: ignore
    except ImportError:
        sys.exit("PyYAML is not installed: `pip install pyyaml`, or pass a .json contract")
    return yaml.safe_load(text)


def validate(c: dict) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warns: list[str] = []
    for key in ("id", "version", "intent", "privacy_class", "constraints", "budget", "acceptance"):
        if key not in c or c[key] in (None, "", []):
            errors.append(f"missing required field: {key}")
    if errors:
        return errors, warns

    if not isinstance(c["version"], int) or c["version"] < 1:
        errors.append("version must be an integer >= 1")
    elif c["version"] > 1 and not c.get("change_reason"):
        errors.append("version > 1 requires change_reason")
    if "REPLACE" in str(c["id"]) or "One sentence" in str(c["intent"]):
        errors.append("template placeholders were not filled in (id or intent)")
    if c["privacy_class"] not in PRIVACY:
        errors.append(f"privacy_class must be one of {sorted(PRIVACY)}")

    k = c["constraints"]
    if not k.get("allowed_paths"):
        errors.append("constraints.allowed_paths must list at least one path")
    forb = k.get("forbidden_paths") or []
    for s in SECRET_DEFAULTS:
        if s not in forb:
            warns.append(f"forbidden_paths does not include the default secret pattern {s!r}")
    if not isinstance(k.get("outbound_network", False), bool):
        errors.append("constraints.outbound_network must be true or false")
    if c["privacy_class"] == "restricted" and k.get("outbound_network"):
        errors.append("restricted contracts cannot allow outbound network")

    b = c["budget"]
    for key in ("api_usd_max", "max_attempts_per_task", "wall_clock_minutes_max"):
        v = b.get(key)
        if not isinstance(v, (int, float)) or v < 0:
            errors.append(f"budget.{key} must be a non-negative number")

    acc = c["acceptance"]
    if not isinstance(acc, list) or not acc:
        errors.append("acceptance must be a non-empty list")
        return errors, warns
    ids, types = set(), set()
    for i, a in enumerate(acc):
        where = f"acceptance[{i}]"
        if not isinstance(a, dict):
            errors.append(f"{where} must be a mapping with id, description and check")
            continue
        if not a.get("id"):
            errors.append(f"{where} needs an id")
        elif a["id"] in ids:
            errors.append(f"{where} duplicate id {a['id']!r}")
        ids.add(a.get("id"))
        chk = a.get("check") or {}
        t = chk.get("type")
        if t not in CHECK_TYPES:
            errors.append(f"{where} check.type must be one of {sorted(CHECK_TYPES)}")
            continue
        types.add(t)
        if t == "command" and not chk.get("run"):
            errors.append(f"{where} command check needs 'run'")
        if t == "file_exists" and not chk.get("path"):
            errors.append(f"{where} file_exists check needs 'path'")
        if t == "rubric" and not chk.get("examples"):
            warns.append(f"{where} rubric check should name calibration 'examples'")
        if "done" in str(a.get("description", "")).lower() and t not in DETERMINISTIC:
            warns.append(f"{where} looks like a self-reported 'done'; prefer a deterministic check")
    if not types & DETERMINISTIC:
        warns.append("no deterministic check (command, file_exists, path_scope, citations); "
                     "acceptable only for subjective work")
    if not c.get("non_goals"):
        warns.append("non_goals is empty; list things the user does not want done")
    return errors, warns


def main() -> None:
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    errors, warns = validate(load(sys.argv[1]))
    for w in warns:
        print(f"WARN  {w}")
    for e in errors:
        print(f"ERROR {e}")
    strict = "--strict" in sys.argv
    if errors or (strict and warns):
        print("INVALID")
        sys.exit(1)
    print("VALID" + (f" with {len(warns)} warning(s)" if warns else ""))


if __name__ == "__main__":
    main()
