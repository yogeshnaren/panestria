---
name: claude-code-worker
description: Run the official Claude Code CLI as a headless worker on the user's own Claude subscription or API key, inside an isolated git worktree, with repo hooks, MCP servers and untrusted instructions neutralized, a pinned flag profile, budget and turn limits, and streamed JSON events. Use when the harness broker delegates a Build task to Claude Code.
license: Apache-2.0
compatibility: Claude Code CLI installed and signed in by the user through Anthropic's own login flow (flag profile checked against the CLI reference on 2026-10-11). Python 3.10+, git. Linux or macOS.
metadata:
  author: agentos
  version: "0.1.0"
  stage: mvp
---

# Claude Code worker

Claude Code runs as a subprocess the user signed into themselves. The orchestrator
never reads, copies or proxies Claude credentials.

## Why this needs care

- Subscription login works only without `--bare`, because bare mode never reads
  OAuth credentials.
- Without `--bare`, `claude -p` runs a repo's `.claude/settings.json` hooks and
  connects its `.mcp.json` servers with no trust prompt. A hostile repo can run code.

## Steps

1. Check sign-in without touching tokens:
   ```bash
   claude auth status          # JSON; authMethod is claude.ai, api_key, ...
   ```
   If not signed in, stop and ask the user to run `claude auth login` themselves.
   Never automate the login or read credential files.
2. Create a dedicated git worktree for the task, then neutralize repo config:
   ```bash
   python3 scripts/prepare_worktree.py <worktree> --apply
   ```
   This quarantines `.claude/` settings and hooks, `.mcp.json` and repo `CLAUDE.md`
   outside the worktree, and refuses on symlinks that escape the worktree or files
   that look like secrets. Exit code 2 means a human must look.
3. Write the task context (goal contract summary, rules, relevant memory) to a file
   and pass it with `--context`; do not rely on repo `CLAUDE.md`.
4. Launch with the pinned profile (see `references/flag-profile.md`):
   ```bash
   python3 scripts/run_worker.py --worktree <path> --prompt-file task.md \
     --context context.md --profile isolated --max-turns 40 --events events.jsonl
   ```
   Add `--dry-run` to print the exact command without running it.
5. Read `events.jsonl`; the final `result` event has the summary, session ID and
   usage. Treat the worker's claim of success as a claim: the verifier decides.
6. To cancel, send SIGINT first so the turn ends cleanly, then SIGTERM if needed
   (`run_worker.py` does this on Ctrl+C or timeout). SIGTERM exits with 143 and
   leaves the in-progress turn unfinished.

## Rules

- Keep plan-backed use at human-like volume: one or a few concurrent sessions.
  Bulk or fully automated work goes to an API key.
- `--permission-prompts none` only denies unanswered prompts. It is not a sandbox;
  run the worker under the OS sandbox and egress policy as well.
- `--max-budget-usd` only applies to API-key runs and is a client-side estimate.
- Pin the CLI version and re-run the adapter contract tests after every upgrade.
