#!/usr/bin/env python3
"""Neutralize repo-controlled agent configuration in a worktree before a headless run.

Usage:
  python3 prepare_worktree.py <worktree>            # report only (dry run)
  python3 prepare_worktree.py <worktree> --apply    # quarantine risky config

Quarantined files move to <worktree>/../.<name>-quarantine/ (outside the worktree).
Exit codes: 0 clean or fixed, 2 needs human review (escaping symlinks, secrets),
1 usage error. Prints a JSON report.
"""
from __future__ import annotations

import fnmatch
import json
import os
import shutil
import sys

QUARANTINE = [            # repo-controlled config that could run code or steer the agent
    ".claude/settings.json", ".claude/settings.local.json", ".claude/hooks",
    ".claude/agents", ".claude/commands", ".claude/skills", ".claude/plugins",
    ".mcp.json", "CLAUDE.md", "CLAUDE.local.md", ".claude/CLAUDE.md",
    "AGENTS.md", ".codex", ".cursor/rules", ".cursorrules",
]
SECRET_GLOBS = [".env", ".env.*", "*.pem", "*.key", "id_rsa*", "id_ed25519*",
                "*.p12", "*.pfx", "credentials.json", ".npmrc", ".pypirc", ".netrc"]
SKIP_DIRS = {".git", "node_modules", ".venv", "venv", "__pycache__"}


def scan(root: str) -> dict:
    root = os.path.realpath(root)
    found, escaping, secrets = [], [], []
    for rel in QUARANTINE:
        if os.path.lexists(os.path.join(root, rel)):
            found.append(rel)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in dirnames + filenames:
            full = os.path.join(dirpath, name)
            rel = os.path.relpath(full, root)
            if os.path.islink(full):
                target = os.path.realpath(full)
                if os.path.commonpath([root, target]) != root:
                    escaping.append({"path": rel, "target": target})
            if name in filenames and any(fnmatch.fnmatch(name, g) for g in SECRET_GLOBS):
                secrets.append(rel)
    return {"root": root, "quarantine": found, "escaping_symlinks": escaping, "secret_like_files": secrets}


def apply(report: dict) -> list[str]:
    root = report["root"]
    qdir = os.path.join(os.path.dirname(root), f".{os.path.basename(root)}-quarantine")
    moved = []
    for rel in report["quarantine"]:
        src = os.path.join(root, rel)
        dst = os.path.join(qdir, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.move(src, dst)
        moved.append(rel)
    report["quarantine_dir"] = qdir
    return moved


def main() -> None:
    if len(sys.argv) < 2 or not os.path.isdir(sys.argv[1]):
        print(__doc__)
        sys.exit(1)
    report = scan(sys.argv[1])
    if "--apply" in sys.argv:
        report["moved"] = apply(report)
        report["quarantine"] = []
    needs_review = bool(report["escaping_symlinks"] or report["secret_like_files"])
    report["status"] = ("needs_review" if needs_review
                        else "risky_config_present" if report["quarantine"] else "clean")
    print(json.dumps(report, indent=2))
    if needs_review:
        sys.exit(2)
    sys.exit(0 if report["status"] == "clean" else 3)


if __name__ == "__main__":
    main()
