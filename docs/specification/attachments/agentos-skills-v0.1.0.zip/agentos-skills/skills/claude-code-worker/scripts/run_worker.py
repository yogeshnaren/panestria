#!/usr/bin/env python3
"""Launch Claude Code headlessly with a pinned flag profile and stream events to a file.

Usage:
  python3 run_worker.py --worktree PATH --prompt-file task.md [--context ctx.md]
      [--profile isolated|safe|readonly|api] [--allowed-tools "Read,Edit,Bash(pytest *)"]
      [--mcp-config mcp.json] [--max-turns 40] [--max-budget-usd 2] [--timeout 3600]
      [--events events.jsonl] [--dry-run]

Never reads or copies Claude credentials. Checks sign-in with `claude auth status`.
Exit code is Claude Code's exit code; 3 = not signed in; 124 = timeout.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import time

EMPTY_MCP = '{"mcpServers": {}}'


def auth_status() -> dict:
    try:
        out = subprocess.run(["claude", "auth", "status"], capture_output=True, text=True, timeout=30)
        return json.loads(out.stdout or "{}")
    except (OSError, json.JSONDecodeError, subprocess.TimeoutExpired):
        return {}


def build(a: argparse.Namespace, prompt: str) -> list[str]:
    cmd = ["claude", "-p", prompt, "--output-format", "stream-json", "--verbose",
           "--max-turns", str(a.max_turns), "--permission-prompts", "none"]
    if a.profile == "api":
        cmd += ["--bare"]
        if a.max_budget_usd:
            cmd += ["--max-budget-usd", str(a.max_budget_usd)]
    else:
        cmd += ["--setting-sources", "user",
                "--strict-mcp-config", "--mcp-config", a.mcp_config or EMPTY_MCP,
                "--permission-mode", "acceptEdits"]
        if a.profile == "safe":
            cmd += ["--safe-mode"]
        if a.profile == "readonly":
            cmd += ["--restricted"]
    if a.context:
        cmd += ["--append-system-prompt-file", a.context]
    if a.allowed_tools:
        cmd += ["--allowedTools", a.allowed_tools]
    return cmd


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--worktree", required=True)
    ap.add_argument("--prompt-file", required=True)
    ap.add_argument("--context")
    ap.add_argument("--profile", default="isolated", choices=["isolated", "safe", "readonly", "api"])
    ap.add_argument("--allowed-tools", default="Read,Edit,Write,Glob,Grep")
    ap.add_argument("--mcp-config")
    ap.add_argument("--max-turns", type=int, default=40)
    ap.add_argument("--max-budget-usd", type=float)
    ap.add_argument("--timeout", type=int, default=3600)
    ap.add_argument("--events", default="events.jsonl")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    with open(a.prompt_file, encoding="utf-8") as f:
        prompt = f.read()
    cmd = build(a, prompt)
    if a.dry_run:
        shown = [c if c != prompt else f"<prompt from {a.prompt_file}>" for c in cmd]
        print(json.dumps({"cwd": os.path.abspath(a.worktree), "command": shown}, indent=2))
        return
    if not shutil.which("claude"):
        sys.exit("claude CLI not found; install it through the official channel")
    if a.profile == "api":
        if not os.environ.get("ANTHROPIC_API_KEY"):
            sys.exit("api profile needs ANTHROPIC_API_KEY from the secret broker")
    else:
        st = auth_status()
        if st.get("authMethod") in (None, "none"):
            print("Not signed in. Ask the user to run `claude auth login` themselves.", file=sys.stderr)
            sys.exit(3)

    start = time.time()
    with open(a.events, "w", encoding="utf-8") as log:
        proc = subprocess.Popen(cmd, cwd=a.worktree, stdout=subprocess.PIPE, text=True)
        try:
            for line in proc.stdout:  # type: ignore[union-attr]
                log.write(line)
                log.flush()
                if time.time() - start > a.timeout:
                    raise TimeoutError
            sys.exit(proc.wait())
        except (KeyboardInterrupt, TimeoutError) as e:
            proc.send_signal(signal.SIGINT)         # end the turn cleanly first
            try:
                proc.wait(timeout=30)
            except subprocess.TimeoutExpired:
                proc.terminate()                     # SIGTERM: exit 143, turn unfinished
                proc.wait(timeout=30)
            sys.exit(124 if isinstance(e, TimeoutError) else 130)


if __name__ == "__main__":
    main()
