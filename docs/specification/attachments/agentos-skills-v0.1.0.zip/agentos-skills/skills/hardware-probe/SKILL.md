---
name: hardware-probe
description: Detect this machine's CPU, RAM, GPU/VRAM or Apple unified memory, disk and power state, then choose local models for the primary AI, embeddings, speech and an on-demand heavy model, plus optional specialist packs (coding, image, vision, tts). Use at install, after a hardware or driver change, when a user asks what can run locally, or before adding a specialist pack.
license: Apache-2.0
compatibility: Python 3.10+ (stdlib only). Linux or macOS. GPU detection uses nvidia-smi, rocm-smi or macOS sysctl/system_profiler when present. Benchmarking needs a local Ollama server.
metadata:
  author: agentos
  version: "0.1.0"
  stage: mvp
---

# Hardware probe and local model selection

Detects what the machine can run and writes a capability manifest that the
broker routes against. Never hand-pick models for the user without running this.

## When to use

- First install, or after new hardware, a driver update or an OS upgrade.
- The user asks "what can I run locally?" or wants a specialist pack.
- A benchmark regressed, or the resource governor reports repeated VRAM pressure.

## Steps

1. Probe and print the plan (read-only, fast):
   ```bash
   python3 scripts/hwprobe.py --json manifest.json
   ```
2. If the user asked for specialists, add them:
   ```bash
   python3 scripts/hwprobe.py --want coding,image,vision,tts --json manifest.json
   ```
3. Show the user the table: role, model, placement (gpu / offload / cpu / unified),
   estimated memory and tok/s, and the "Restricted work" line.
4. Only with explicit approval, measure real speed. `--pull` downloads every chosen
   model and can use tens of GB of disk and bandwidth:
   ```bash
   python3 scripts/hwprobe.py --pull --benchmark --json manifest.json
   ```
5. Save `manifest.json` where the kernel expects it and report what changed versus
   the previous manifest.

## Rules

- Estimates are labeled estimates until `--benchmark` replaces them. Never present
  them as guarantees.
- Respect pinned models in user settings; if the probe disagrees, warn, don't switch.
- Exactly one primary model. It stays on the accelerator when one exists; the heavy
  model and GPU-only specialists may swap with it, CPU-capable packs never displace it.
- If a role shows `none`, route that role to an approved cloud backend, or refuse it
  for Restricted data. Never silently send Restricted data to the cloud.
- On battery (`AC power: False`), do not benchmark.

## Simulating other machines

`--preset lite-16gb | omen-8gb | omen-12gb | omen-16gb | mac-studio-512` shows what
another profile would pick. Use it for CI and for planning hardware upgrades.

## Output fields

`hardware` (detected specs), `budgets` (accelerator and host-offload GB),
`engine` (recommended runtime), `assignments[]` (role, model, placement,
est_mem_gb, est_tps, measured_tps, degraded, reason), `restricted_capability`.
