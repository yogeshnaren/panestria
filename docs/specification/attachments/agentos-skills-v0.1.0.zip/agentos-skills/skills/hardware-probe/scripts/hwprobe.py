#!/usr/bin/env python3
"""
hwprobe.py - detect local hardware and choose local models for the orchestrator.

Stdlib only (Python 3.10+), so it can run before anything else is installed.

What it does
  1. Probes OS, CPU (cores, ISA flags), RAM, GPU (NVIDIA / AMD / Apple Silicon),
     disk space and power state.
  2. Computes memory budgets for the accelerator (VRAM or unified memory) and
     for host RAM, after reserving room for the OS and the orchestrator's services.
  3. For each role (the primary "steward", embedder, speech-to-text, heavy,
     plus any specialist packs you ask for with --want) picks the most
     capable model from a catalog that fits the budget AND meets the role's
     minimum speed, estimated from memory bandwidth.
  4. Optionally benchmarks the chosen models through a local Ollama server and
     replaces the estimates with measured tokens/s, stepping down if too slow.
  5. Writes a capability manifest (JSON) that the broker routes against.

Usage
  python3 hwprobe.py                      # probe this machine, print the plan
  python3 hwprobe.py --json manifest.json # also write the manifest
  python3 hwprobe.py --preset omen-8gb    # simulate another machine
  python3 hwprobe.py --list-presets
  python3 hwprobe.py --benchmark          # measure with Ollama (models must be pulled)
  python3 hwprobe.py --pull --benchmark   # pull chosen models with Ollama, then measure
  python3 hwprobe.py --want coding,image  # add specialist packs sized for this machine

The catalog below is an EXAMPLE with approximate 4-bit sizes. In the real system
it is a versioned file that the scout updates as new models ship.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
import urllib.request
from dataclasses import asdict, dataclass, field

# --------------------------------------------------------------------------- #
# Tunables
# --------------------------------------------------------------------------- #
EFFICIENCY = 0.55          # fraction of peak memory bandwidth real decoding reaches
OS_RESERVE_GB = 6.0        # desktop OS + apps
SERVICES_RESERVE_GB = 5.0  # Postgres, tracing, kernel, workers
VRAM_RESERVE_GB = 1.0      # driver, display, fragmentation
OVERHEAD_GB = 0.4          # runtime buffers per loaded model
KV_FACTOR = 0.5            # q8_0 KV cache (OLLAMA_KV_CACHE_TYPE=q8_0 + flash attention)

# --------------------------------------------------------------------------- #
# Example catalog (approximate Q4 sizes; kv_gb_per_1k = fp16 KV cache per 1k tokens)
# --------------------------------------------------------------------------- #
CATALOG = {
    "llm": [
        # tag,                total_b, active_b, size_gb, kv_gb_per_1k, tier
        ("qwen3:1.7b",          1.7,   1.7,   1.4, 0.11, 1),
        ("qwen3:4b",            4.0,   4.0,   2.6, 0.14, 2),
        ("qwen3:8b",            8.2,   8.2,   5.2, 0.14, 3),
        ("qwen3:14b",          14.8,  14.8,   9.3, 0.16, 4),
        ("gpt-oss:20b",        21.0,   3.6,  13.0, 0.05, 4),
        ("qwen3:30b-a3b",      30.5,   3.3,  18.6, 0.10, 5),
        ("qwen3:32b",          32.8,  32.8,  20.0, 0.26, 5),
        ("gpt-oss:120b",      117.0,   5.1,  65.0, 0.07, 6),
        ("qwen3:235b-a22b",   235.0,  22.0, 142.0, 0.19, 7),
    ],
    "embedder": [
        ("nomic-embed-text",       0.3, 1),
        ("qwen3-embedding:0.6b",   0.6, 2),
        ("qwen3-embedding:8b",     4.7, 3),
    ],
    "stt": [  # faster-whisper model sizes
        ("whisper-base",           0.2, 1),
        ("whisper-small",          0.5, 2),
        ("whisper-large-v3-turbo", 1.6, 3),
    ],
}

ROLES = {
    #            ctx tokens, min tok/s, allowed tiers, resident?
    "steward": dict(ctx=8192,  min_tps=25.0, tiers=range(1, 6), resident=True),
    "heavy":   dict(ctx=16384, min_tps=8.0,  tiers=range(4, 8), resident=False),
}

# Specialist packs you can add per use case. LLM packs reuse the placement logic;
# the others are sized by memory needed. Examples only; the scout keeps this current.
SPECIALIST_LLM = {
    #  pack: (ctx, min tok/s, [(tag, total_b, active_b, size_gb, kv_gb_per_1k, tier)])
    "coding": (32768, 10.0, [
        ("qwen2.5-coder:7b",   7.6,  7.6,  4.7, 0.06, 1),
        ("qwen2.5-coder:14b", 14.8, 14.8,  9.0, 0.19, 2),
        ("qwen3-coder:30b",   30.5,  3.3, 18.6, 0.10, 3),
    ]),
    "vision": (8192, 10.0, [
        ("qwen2.5vl:3b",  3.8,  3.8, 3.2, 0.04, 1),
        ("qwen2.5vl:7b",  8.3,  8.3, 6.0, 0.06, 2),
        ("qwen2.5vl:32b", 33.5, 33.5, 21.0, 0.26, 3),
    ]),
}
SPECIALIST_OTHER = {
    # pack: [(name, mem_gb, needs_accelerator, tier, runtime)]
    "image": [
        ("stable-diffusion-1.5",      4.0, True, 1, "ComfyUI or diffusers (mflux / Draw Things on Mac)"),
        ("sdxl",                      8.0, True, 2, "ComfyUI or diffusers"),
        ("flux.1-schnell (4-bit)",   10.0, True, 3, "ComfyUI with GGUF"),
    ],
    "tts": [
        ("kokoro-82m",                0.5, False, 1, "kokoro"),
    ],
}

APPLE_BANDWIDTH = {  # GB/s, by chip name
    "M1": 68, "M1 Pro": 200, "M1 Max": 400, "M1 Ultra": 800,
    "M2": 100, "M2 Pro": 200, "M2 Max": 400, "M2 Ultra": 800,
    "M3": 100, "M3 Pro": 150, "M3 Max": 400, "M3 Ultra": 819,
    "M4": 120, "M4 Pro": 273, "M4 Max": 546,
    "M5": 153, "M5 Max": 614, "M5 Ultra": 1200,
}
# Rough NVIDIA bandwidth by VRAM class (GB/s); the benchmark replaces it.
NVIDIA_LAPTOP_BW = {8: 256, 12: 432, 16: 576, 24: 896}
NVIDIA_DESKTOP_BW = {8: 272, 12: 504, 16: 717, 24: 1008, 32: 1792}


# --------------------------------------------------------------------------- #
# Data classes
# --------------------------------------------------------------------------- #
@dataclass
class GPU:
    vendor: str
    name: str
    vram_gb: float
    free_gb: float | None = None
    bandwidth_gbs: float | None = None
    bandwidth_source: str = "estimate"
    cores: int | None = None
    compute_cap: str | None = None
    driver: str | None = None


@dataclass
class Hardware:
    os: str
    arch: str
    cpu: str
    physical_cores: int | None
    logical_cores: int | None
    cpu_flags: list[str]
    ram_gb: float
    ram_available_gb: float | None
    unified_memory: bool
    gpus: list[GPU] = field(default_factory=list)
    cpu_bandwidth_gbs: float = 60.0
    disk_free_gb: float | None = None
    on_ac_power: bool | None = None
    notes: list[str] = field(default_factory=list)


@dataclass
class Choice:
    role: str
    model: str | None
    placement: str = "none"          # gpu | unified | offload | cpu | none
    est_mem_gb: float = 0.0
    est_tps: float | None = None
    measured_tps: float | None = None
    ctx: int | None = None
    degraded: bool = False
    reason: str = ""


# --------------------------------------------------------------------------- #
# Probing helpers
# --------------------------------------------------------------------------- #
def run(cmd: list[str], timeout: int = 10) -> str | None:
    if not shutil.which(cmd[0]):
        return None
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return out.stdout if out.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def read(path: str) -> str | None:
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            return f.read()
    except OSError:
        return None


def probe_cpu_linux() -> tuple[str, int | None, list[str]]:
    info = read("/proc/cpuinfo") or ""
    name = next((l.split(":", 1)[1].strip() for l in info.splitlines()
                 if l.startswith("model name")), platform.processor() or "unknown")
    cores = {(m.group(1), m.group(2)) for m in
             re.finditer(r"physical id\s*:\s*(\d+).*?core id\s*:\s*(\d+)", info, re.S)}
    flags_line = next((l for l in info.splitlines() if l.startswith("flags")), "")
    wanted = ("avx2", "avx512f", "amx_tile", "avx_vnni", "fma")
    flags = [f for f in wanted if f" {f}" in f" {flags_line} "]
    return name, (len(cores) or None), flags


def probe_ram_linux() -> tuple[float, float | None]:
    mem = read("/proc/meminfo") or ""
    def kb(key: str) -> float | None:
        m = re.search(rf"^{key}:\s+(\d+)", mem, re.M)
        return int(m.group(1)) / 1024 / 1024 if m else None
    return kb("MemTotal") or 0.0, kb("MemAvailable")


def probe_nvidia() -> list[GPU]:
    fields = "name,memory.total,memory.free,driver_version,compute_cap"
    out = run(["nvidia-smi", f"--query-gpu={fields}", "--format=csv,noheader,nounits"])
    if out is None:  # older drivers lack compute_cap
        fields = "name,memory.total,memory.free,driver_version"
        out = run(["nvidia-smi", f"--query-gpu={fields}", "--format=csv,noheader,nounits"])
    gpus = []
    for line in (out or "").strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 4:
            continue
        name, total, free, driver = parts[:4]
        vram = round(float(total) / 1024, 1)
        cls = min(NVIDIA_LAPTOP_BW if "laptop" in name.lower() else NVIDIA_DESKTOP_BW,
                  key=lambda k: abs(k - vram))
        table = NVIDIA_LAPTOP_BW if "laptop" in name.lower() else NVIDIA_DESKTOP_BW
        gpus.append(GPU("nvidia", name, vram, round(float(free) / 1024, 1),
                        table[cls], "estimate by VRAM class",
                        compute_cap=parts[4] if len(parts) > 4 else None, driver=driver))
    return gpus


def probe_amd() -> list[GPU]:
    out = run(["rocm-smi", "--showproductname", "--showmeminfo", "vram", "--json"])
    if not out:
        return []
    try:
        data = json.loads(out)
    except json.JSONDecodeError:
        return []
    gpus = []
    for card, vals in data.items():
        total = next((v for k, v in vals.items() if "Total Memory" in k), None)
        name = vals.get("Card Series") or vals.get("Card SKU") or card
        if total:
            vram = round(int(total) / 1024**3, 1)
            gpus.append(GPU("amd", str(name), vram, None, 400.0, "rough estimate"))
    return gpus


def probe_apple() -> tuple[str, float, GPU | None, int | None]:
    chip = (run(["sysctl", "-n", "machdep.cpu.brand_string"]) or "Apple").strip()
    ram = int((run(["sysctl", "-n", "hw.memsize"]) or "0").strip() or 0) / 1024**3
    phys = run(["sysctl", "-n", "hw.physicalcpu"])
    cores = None
    sp = run(["system_profiler", "SPDisplaysDataType", "-json"], timeout=20)
    if sp:
        try:
            disp = json.loads(sp).get("SPDisplaysDataType", [{}])[0]
            cores = int(disp.get("sppci_cores", 0)) or None
        except (json.JSONDecodeError, ValueError, IndexError):
            pass
    key = re.sub(r"^Apple\s+", "", chip)
    bw = APPLE_BANDWIDTH.get(key)
    gpu_share = 0.67 if ram <= 36 else 0.75   # default GPU wired-memory limit
    gpu = GPU("apple", chip, round(ram * gpu_share, 1), None, bw,
              "chip table" if bw else "unknown", cores=cores)
    return chip, ram, gpu, int(phys) if phys and phys.strip().isdigit() else None


def probe_power() -> bool | None:
    if sys.platform == "darwin":
        out = run(["pmset", "-g", "batt"]) or ""
        return "AC Power" in out if out else None
    base = "/sys/class/power_supply"
    if not os.path.isdir(base):
        return None
    for dev in os.listdir(base):
        if (read(f"{base}/{dev}/type") or "").strip() == "Mains":
            return (read(f"{base}/{dev}/online") or "").strip() == "1"
    return None


def probe() -> Hardware:
    system, arch = platform.system(), platform.machine()
    notes: list[str] = []
    if system == "Darwin" and arch == "arm64":
        chip, ram, gpu, phys = probe_apple()
        hw = Hardware("macOS", arch, chip, phys, os.cpu_count(), ["neon"], round(ram, 1),
                      None, True, [gpu] if gpu else [], cpu_bandwidth_gbs=gpu.bandwidth_gbs or 100)
        notes.append("Raise the GPU memory limit with: sudo sysctl iogpu.wired_limit_mb=<MB>")
    else:
        cpu, phys, flags = probe_cpu_linux() if system == "Linux" else (platform.processor(), None, [])
        ram, avail = probe_ram_linux() if system == "Linux" else (0.0, None)
        gpus = probe_nvidia() or probe_amd()
        hw = Hardware(system, arch, cpu, phys, os.cpu_count(), flags, round(ram, 1),
                      round(avail, 1) if avail else None, False, gpus)
        if system == "Linux" and gpus and gpus[0].vendor == "nvidia":
            mode = (run(["prime-select", "query"]) or "").strip()
            if mode and mode != "on-demand":
                notes.append(f"prime-select is '{mode}'; 'on-demand' frees VRAM from the display")
    try:
        hw.disk_free_gb = round(shutil.disk_usage(os.path.expanduser("~")).free / 1024**3, 1)
    except OSError:
        pass
    hw.on_ac_power = probe_power()
    hw.notes = notes
    return hw


# --------------------------------------------------------------------------- #
# Presets for simulation (and CI)
# --------------------------------------------------------------------------- #
def preset(name: str) -> Hardware:
    linux = dict(os="Linux", arch="x86_64", cpu="Intel Core i7 (laptop)",
                 physical_cores=14, logical_cores=20, cpu_flags=["avx2", "fma"],
                 ram_gb=32.0, ram_available_gb=28.0, unified_memory=False,
                 cpu_bandwidth_gbs=60.0, disk_free_gb=400.0, on_ac_power=True)
    p = {
        "lite-16gb":  dict(linux, ram_gb=16.0, ram_available_gb=12.0, cpu="Intel Core i5 (laptop)"),
        "omen-8gb":   dict(linux, gpus=[GPU("nvidia", "NVIDIA GeForce RTX 4070 Laptop GPU", 8.0, 7.6, 256)]),
        "omen-12gb":  dict(linux, gpus=[GPU("nvidia", "NVIDIA GeForce RTX 4080 Laptop GPU", 12.0, 11.6, 432)]),
        "omen-16gb":  dict(linux, gpus=[GPU("nvidia", "NVIDIA GeForce RTX 4090 Laptop GPU", 16.0, 15.6, 576)]),
        "mac-studio-512": dict(os="macOS", arch="arm64", cpu="Apple M5 Ultra", physical_cores=36,
                               logical_cores=36, cpu_flags=["neon"], ram_gb=512.0,
                               ram_available_gb=None, unified_memory=True, cpu_bandwidth_gbs=1200,
                               gpus=[GPU("apple", "Apple M5 Ultra", 384.0, None, 1200, "chip table", cores=80)],
                               disk_free_gb=2000.0, on_ac_power=True),
    }
    if name not in p:
        sys.exit(f"unknown preset '{name}'; try --list-presets")
    return Hardware(**p[name])


# --------------------------------------------------------------------------- #
# Selection
# --------------------------------------------------------------------------- #
def budgets(hw: Hardware) -> tuple[float, float, float]:
    """Return (accelerator_gb, host_offload_gb, accelerator_bandwidth)."""
    reserve = min(OS_RESERVE_GB + SERVICES_RESERVE_GB, hw.ram_gb * 0.5)
    host = max(0.0, hw.ram_gb - reserve)
    if hw.unified_memory and hw.gpus:
        g = hw.gpus[0]
        accel = min(g.vram_gb, host)
        return accel, 0.0, g.bandwidth_gbs or hw.cpu_bandwidth_gbs
    if hw.gpus:
        g = max(hw.gpus, key=lambda x: x.vram_gb)
        free = g.free_gb if g.free_gb is not None else g.vram_gb
        return max(0.0, min(g.vram_gb, free) - VRAM_RESERVE_GB), host, g.bandwidth_gbs or 256
    return 0.0, host, hw.cpu_bandwidth_gbs


def place(size_gb, active_frac, kv_per_1k, ctx, accel, host, accel_bw, cpu_bw, unified):
    mem = size_gb + KV_FACTOR * kv_per_1k * ctx / 1000 + OVERHEAD_GB
    active_bytes = size_gb * active_frac
    if mem <= accel:
        return ("unified" if unified else "gpu"), mem, EFFICIENCY * accel_bw / active_bytes
    if not unified and accel > 0 and mem <= accel + host:
        f_cpu = (mem - accel) / mem
        t = active_bytes * ((1 - f_cpu) / accel_bw + f_cpu / cpu_bw)
        return "offload", mem, EFFICIENCY / t
    if mem <= host:
        return "cpu", mem, EFFICIENCY * cpu_bw / active_bytes
    return None, mem, 0.0


def pick_llm(role: str, hw: Hardware, accel: float, host: float, accel_bw: float,
             min_tier: int = 0) -> Choice:
    spec = ROLES[role]
    options = []
    for tag, total, active, size, kv, tier in CATALOG["llm"]:
        if tier not in spec["tiers"] or tier <= min_tier:
            continue
        where, mem, tps = place(size, active / total, kv, spec["ctx"], accel, host,
                                accel_bw, hw.cpu_bandwidth_gbs, hw.unified_memory)
        # The always-on steward must stay on the accelerator when there is one:
        # spilling it into system RAM slows every request and starves the heavy model.
        if role == "steward" and accel > 0 and where in ("offload", "cpu"):
            continue
        if where:
            options.append((tier, tps, tag, where, mem))
    for floor, degraded in ((spec["min_tps"], False), (spec["min_tps"] / 2, True)):
        ok = [o for o in options if o[1] >= floor]
        if ok:
            tier, tps, tag, where, mem = max(ok, key=lambda o: (o[0], o[1]))
            why = f"tier {tier}, fits {where}, ~{tps:.0f} tok/s"
            if degraded:
                why += f" (below the {spec['min_tps']:.0f} tok/s target)"
            return Choice(role, tag, where, round(mem, 1), round(tps, 1), None, spec["ctx"], degraded, why)
    return Choice(role, None, reason="nothing fits at a usable speed; route this role to the cloud")


def pick_small(kind: str, role: str, accel: float, host: float, unified: bool) -> Choice:
    for tag, size, _tier in sorted(CATALOG[kind], key=lambda x: -x[2]):
        mem = size + 0.2
        if mem <= accel:
            return Choice(role, tag, "unified" if unified else "gpu", round(mem, 1), reason="fits on accelerator")
    for tag, size, _tier in sorted(CATALOG[kind], key=lambda x: -x[2]):
        if size + 0.2 <= host and size <= 0.6:   # keep CPU-side helpers small
            return Choice(role, tag, "cpu", round(size + 0.2, 1), reason="runs on CPU")
    return Choice(role, None, reason="no room")


def select(hw: Hardware, want: list[str] | None = None) -> tuple[list[Choice], dict]:
    accel, host, accel_bw = budgets(hw)
    b = dict(accelerator_gb=round(accel, 1), host_offload_gb=round(host, 1),
             accelerator_bandwidth_gbs=accel_bw, cpu_bandwidth_gbs=hw.cpu_bandwidth_gbs)
    choices = []
    steward = pick_llm("steward", hw, accel, host, accel_bw)
    choices.append(steward)
    a, h = accel, host
    if steward.model:
        if steward.placement in ("gpu", "unified"):
            a -= steward.est_mem_gb
        else:
            h -= steward.est_mem_gb
    heavy_a, heavy_h = a, h   # heavy may briefly unload embedder/STT, never the steward
    for kind, role in (("embedder", "embedder"), ("stt", "stt")):
        c = pick_small(kind, role, a, h, hw.unified_memory)
        choices.append(c)
        if c.model:
            if c.placement in ("gpu", "unified"):
                a -= c.est_mem_gb
            else:
                h -= c.est_mem_gb
    tiers = {t[0]: t[5] for t in CATALOG["llm"]}
    floor = tiers.get(steward.model, 0)
    heavy = pick_llm("heavy", hw, heavy_a, heavy_h, accel_bw, min_tier=floor)  # loaded on demand
    if not heavy.model:
        heavy.reason = "nothing stronger than the steward fits; heavy work goes to the cloud or waits"
    choices.append(heavy)
    for pack in want or []:
        choices.append(pick_specialist(pack, hw, heavy_a, accel, heavy_h, accel_bw))
    return choices, b


def pick_specialist(pack: str, hw: Hardware, alongside: float, accel: float, host: float,
                    accel_bw: float) -> Choice:
    """Specialists load on demand. 'alongside' = accelerator memory free next to the
    primary; 'accel' = the whole accelerator, usable only if the primary steps aside."""
    role = f"+{pack}"
    if pack in SPECIALIST_LLM:
        ctx, min_tps, models = SPECIALIST_LLM[pack]
        best = None
        for tag, total, active, size, kv, tier in models:
            for budget, note in ((alongside, ""), (accel, "primary drops to a CPU fallback during the job")):
                where, mem, tps = place(size, active / total, kv, ctx, budget, host,
                                        accel_bw, hw.cpu_bandwidth_gbs, hw.unified_memory)
                if where and tps >= min_tps:
                    cand = (tier, tps, tag, where, mem, note)
                    if best is None or cand[:2] > best[:2]:
                        best = cand
                    break
        if best:
            tier, tps, tag, where, mem, note = best
            return Choice(role, tag, where, round(mem, 1), round(tps, 1), None, ctx,
                          reason=note or f"fits {where}")
        return Choice(role, None, reason="too slow or too large here; use a cloud route")
    if pack in SPECIALIST_OTHER:
        for name, mem, needs_accel, tier, runtime in sorted(SPECIALIST_OTHER[pack], key=lambda x: -x[3]):
            if mem <= alongside:
                return Choice(role, name, "unified" if hw.unified_memory else "gpu", mem, reason=runtime)
            if not needs_accel and mem <= host:     # never displace the primary for CPU-capable work
                return Choice(role, name, "cpu", mem, reason=runtime)
            if needs_accel and mem <= accel:
                return Choice(role, name, "unified" if hw.unified_memory else "gpu", mem,
                              reason=f"{runtime}; primary drops to a CPU fallback during the job")
        return Choice(role, None, reason="needs a GPU or Apple Silicon with more memory; use a cloud route")
    sys.exit(f"unknown pack '{pack}'; choose from {', '.join([*SPECIALIST_LLM, *SPECIALIST_OTHER])}")


def restricted_capability(choices: list[Choice]) -> str:
    heavy = next(c for c in choices if c.role == "heavy")
    steward = next(c for c in choices if c.role == "steward")
    tier = {t[0]: t[5] for t in CATALOG["llm"]}
    if heavy.model and tier[heavy.model] >= 6:
        return "full: Restricted planning and coding run locally"
    if heavy.model:
        return "reduced: Restricted coding and planning run locally, slower and weaker than frontier"
    if steward.model:
        return "triage only: Restricted work is queued or refused, never sent"
    return "none: no usable local model; Restricted work is refused"


def engine_for(hw: Hardware) -> str:
    if hw.unified_memory:
        return "mlx-lm or Ollama (Metal)"
    if hw.gpus and hw.gpus[0].vendor == "nvidia":
        return "Ollama or llama.cpp (CUDA); vLLM/SGLang for models that fit fully in VRAM"
    if hw.gpus and hw.gpus[0].vendor == "amd":
        return "llama.cpp (ROCm or Vulkan)"
    return "llama.cpp (CPU)"


# --------------------------------------------------------------------------- #
# Benchmark via Ollama
# --------------------------------------------------------------------------- #
OLLAMA = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")
BENCH_PROMPT = "Summarize in five bullet points why durable workflow state matters for long-running AI agents."


def ollama_bench(model: str) -> float | None:
    body = json.dumps({"model": model, "prompt": BENCH_PROMPT, "stream": False,
                       "options": {"num_predict": 128}}).encode()
    req = urllib.request.Request(f"{OLLAMA}/api/generate", body, {"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            d = json.load(r)
        return round(d["eval_count"] / (d["eval_duration"] / 1e9), 1)
    except Exception as e:  # noqa: BLE001
        print(f"  benchmark failed for {model}: {e}", file=sys.stderr)
        return None


def benchmark(choices: list[Choice], pull: bool) -> None:
    for c in choices:
        if not c.model or c.role not in ROLES:
            continue
        if pull and shutil.which("ollama"):
            print(f"  pulling {c.model} ...", file=sys.stderr)
            subprocess.run(["ollama", "pull", c.model], check=False)
        ollama_bench(c.model)               # warm-up load
        c.measured_tps = ollama_bench(c.model)
        if c.measured_tps is not None and c.measured_tps < ROLES[c.role]["min_tps"]:
            c.degraded = True
            c.reason += f"; measured {c.measured_tps} tok/s is below target, consider the next tier down"


# --------------------------------------------------------------------------- #
# Output
# --------------------------------------------------------------------------- #
def report(hw: Hardware, choices: list[Choice], b: dict) -> str:
    g = hw.gpus[0] if hw.gpus else None
    lines = [
        f"OS        {hw.os} {hw.arch}   AC power: {hw.on_ac_power}",
        f"CPU       {hw.cpu}  ({hw.physical_cores or '?'} physical / {hw.logical_cores or '?'} logical)"
        + (f"  flags: {', '.join(hw.cpu_flags)}" if hw.cpu_flags else ""),
        f"RAM       {hw.ram_gb} GB" + (f" ({hw.ram_available_gb} GB available)" if hw.ram_available_gb else "")
        + ("  unified" if hw.unified_memory else ""),
        f"GPU       {g.name}, {g.vram_gb} GB" + (f", {g.cores} cores" if g and g.cores else "")
        + (f", ~{g.bandwidth_gbs:.0f} GB/s ({g.bandwidth_source})" if g and g.bandwidth_gbs else "")
        if g else "GPU       none detected",
        f"Disk free {hw.disk_free_gb} GB",
        "",
        f"Budgets   accelerator {b['accelerator_gb']} GB, host offload {b['host_offload_gb']} GB",
        f"Engine    {engine_for(hw)}",
        "Assumes  4-bit weights, q8_0 KV cache (OLLAMA_KV_CACHE_TYPE=q8_0, OLLAMA_FLASH_ATTENTION=1)",
        "",
        f"{'Role':<10}{'Model':<24}{'Where':<9}{'Mem GB':>7}{'Est tok/s':>11}{'Measured':>10}",
    ]
    for c in choices:
        est = f"{c.est_tps:.0f}" if c.est_tps else "-"
        meas = f"{c.measured_tps:.0f}" if c.measured_tps else "-"
        lines.append(f"{c.role:<10}{(c.model or '-'):<24}{c.placement:<9}{c.est_mem_gb:>7}{est:>11}{meas:>10}"
                     + ("  degraded" if c.degraded else ""))
    for c in choices:
        if c.role.startswith("+"):
            lines.append(f"  {c.role[1:]}: {c.reason}")
    lines += ["", f"Restricted work: {restricted_capability(choices)}"]
    sizes = {t[0]: t[3] for t in CATALOG["llm"]}
    sizes.update({t[0]: t[1] for k in ("embedder", "stt") for t in CATALOG[k]})
    sizes.update({t[0]: t[3] for _, _, ms in SPECIALIST_LLM.values() for t in ms})
    sizes.update({t[0]: t[1] for ms in SPECIALIST_OTHER.values() for t in ms})
    need = sum(sizes.get(c.model, 0) for c in choices if c.model)
    if hw.disk_free_gb is not None and need > hw.disk_free_gb * 0.8:
        lines.append(f"Warning: models need ~{need:.0f} GB of disk; only {hw.disk_free_gb} GB free")
    if hw.on_ac_power is False:
        lines.append("On battery: heavy local jobs will wait for AC power")
    lines += [f"Note: {n}" for n in hw.notes]
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--preset", help="simulate a machine instead of probing this one")
    ap.add_argument("--list-presets", action="store_true")
    ap.add_argument("--json", metavar="PATH", help="write the capability manifest here")
    ap.add_argument("--benchmark", action="store_true", help="measure tok/s through local Ollama")
    ap.add_argument("--pull", action="store_true", help="ollama pull the chosen models first")
    ap.add_argument("--want", default="", help="specialist packs to add, e.g. coding,image,vision,tts")
    args = ap.parse_args()

    if args.list_presets:
        print("lite-16gb  omen-8gb  omen-12gb  omen-16gb  mac-studio-512")
        return
    hw = preset(args.preset) if args.preset else probe()
    want = [w.strip() for w in args.want.split(",") if w.strip()]
    choices, b = select(hw, want)
    if args.benchmark:
        benchmark(choices, args.pull)
    print(report(hw, choices, b))
    if args.json:
        manifest = dict(generated_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"), simulated=bool(args.preset),
                        hardware=asdict(hw), budgets=b, engine=engine_for(hw),
                        assignments=[asdict(c) for c in choices],
                        restricted_capability=restricted_capability(choices))
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)
        print(f"\nManifest written to {args.json}")


if __name__ == "__main__":
    main()
