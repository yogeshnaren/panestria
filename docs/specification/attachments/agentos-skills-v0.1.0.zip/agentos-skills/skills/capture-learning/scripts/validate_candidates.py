#!/usr/bin/env python3
"""Validate a candidates.jsonl file of learning observations.

Usage: python3 validate_candidates.py candidates.jsonl
Exit 0 if every line is valid, 1 otherwise.
"""
from __future__ import annotations

import json
import re
import sys

COMMON = {"type", "scope", "source", "privacy_class", "confidence", "proposed_by"}
REQUIRED = {
    "correction": {"content"},
    "preference": {"content"},
    "fact": {"content"},
    "skill_idea": {"content", "trigger"},
    "routing_observation": {"backend", "task_class", "outcome"},
    "memory_usage": {"memory_id", "used", "task_outcome"},
    "miss": {"content"},
}
PRIVACY = {"restricted", "confidential", "internal", "public"}
SECRETS = [
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY"),
    re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"),
    re.compile(r"\b(?:ghp|gho|ghs)_[A-Za-z0-9]{36,}\b"),
    re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"\b(?:\d[ -]?){13,19}\b"),  # card-like digit runs
]


def check(obj: dict) -> list[str]:
    errs = []
    t = obj.get("type")
    if t not in REQUIRED:
        return [f"unknown type {t!r}; expected one of {sorted(REQUIRED)}"]
    for k in (COMMON | REQUIRED[t]) - obj.keys():
        errs.append(f"missing {k}")
    src = obj.get("source") or {}
    if not isinstance(src, dict) or not src.get("task_id") or not src.get("evidence"):
        errs.append("source needs task_id and evidence")
    if obj.get("privacy_class") not in PRIVACY:
        errs.append(f"privacy_class must be one of {sorted(PRIVACY)}")
    c = obj.get("confidence")
    if not isinstance(c, (int, float)) or not 0 <= c <= 1:
        errs.append("confidence must be a number from 0 to 1")
    if t == "memory_usage" and not isinstance(obj.get("used"), bool):
        errs.append("used must be true or false")
    blob = json.dumps(obj)
    if any(p.search(blob) for p in SECRETS):
        errs.append("looks like it contains a secret or account number; remove it")
    return errs


def main() -> None:
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    bad = 0
    total = 0
    with open(sys.argv[1], encoding="utf-8") as f:
        for n, line in enumerate(f, 1):
            if not line.strip():
                continue
            total += 1
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                print(f"line {n}: invalid JSON ({e})")
                bad += 1
                continue
            for e in check(obj):
                print(f"line {n}: {e}")
            bad += bool(check(obj))
    if bad:
        print(f"INVALID: {bad} of {total} line(s)")
        sys.exit(1)
    print(f"VALID: {total} candidate(s)")


if __name__ == "__main__":
    main()
