---
name: capture-learning
description: At the end of every task, record what was learned as candidate entries - user corrections, preferences, durable facts, skill ideas, routing observations and memory usage - with provenance and privacy labels, into an append-only candidates file. Never edits memory, skills or routing directly. Use after any task finishes, fails or receives user feedback.
license: Apache-2.0
compatibility: Python 3.10+ (stdlib only).
metadata:
  author: agentos
  version: "0.1.0"
  stage: mvp
---

# Capture learning

Self-improvement starts with evidence. This skill records raw, attributable
observations now, so the later learning loop can evaluate and promote them. It
never changes memory, skills, permissions or routing itself.

## When

After every task: completed, failed, cancelled, or when the user corrects or rates
the result. Also when an agent re-asks something the system should have known.

## Steps

1. Append one JSON object per line to `candidates.jsonl` in the task's run folder,
   using the shapes in `assets/candidate.examples.jsonl`.
2. Validate before the run closes:
   ```bash
   python3 scripts/validate_candidates.py candidates.jsonl
   ```
3. Stop there. Promotion happens elsewhere, through replay evals and, for standing
   rules, skills and permissions, user approval.

## Candidate types

| type | Record when | Key fields |
| --- | --- | --- |
| `correction` | The user changed or rejected output | `content` (what they wanted), `before`, `after` |
| `preference` | The user stated how they want things done | `content`, `scope` |
| `fact` | A durable fact about a project or the user surfaced | `content`, `scope`, `valid_from` |
| `skill_idea` | A multi-step procedure worked and may recur | `content` (steps), `trigger` |
| `routing_observation` | A backend succeeded or failed on a task class | `backend`, `task_class`, `outcome`, `cost_usd` |
| `memory_usage` | A memory item was in the context pack | `memory_id`, `used` (true/false), `task_outcome` |
| `miss` | Something known had to be re-asked or re-derived | `content`, `memory_id` if found later |

Every candidate needs `source` (`task_id` plus `evidence`: a message, diff or test
result reference), `privacy_class`, `confidence` (0 to 1) and `proposed_by`.

## Rules

- Record the user's words for corrections and preferences; don't paraphrase them
  into something stronger.
- Label privacy as the strictest class of any input it came from.
- Never record secrets, credentials or card or account numbers.
- One observation per line; small and specific beats long and vague.
