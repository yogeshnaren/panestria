# Example: skills and headless Claude Code

## Summary
- Skills are folders with a SKILL.md file, and headless Claude Code needs care with repo config. [S1][S2]

## Findings
- A skill's name "must be 1-64 characters and must match the parent directory name" [S1]
- "Bare mode never reads OAuth credentials or the system keychain" [S2]
- Non-bare headless runs load project hooks and MCP servers without a trust prompt. [S2]

## Open questions
- Whether every harness honors allowed-tools in the same way.

## Sources
- S1: Agent Skills specification - https://agentskills.io/specification (fetched 2026-10-11)
- S2: Run Claude Code programmatically - https://code.claude.com/docs/en/headless (fetched 2026-10-11)
