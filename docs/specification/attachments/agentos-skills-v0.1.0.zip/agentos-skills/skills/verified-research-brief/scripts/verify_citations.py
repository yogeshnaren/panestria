#!/usr/bin/env python3
"""Check that a research brief is grounded in saved sources.

Usage: python3 verify_citations.py brief.md sources.json
Exit 0 when every check passes, 1 otherwise. Warnings do not fail the run.
"""
from __future__ import annotations

import json
import os
import re
import sys
from datetime import datetime

CITE = re.compile(r"\[(S\d+)\]")
QUOTE = re.compile(r'"([^"]{20,})"\s*((?:\[S\d+\])+)')
EXEMPT_SECTIONS = {"sources", "open questions", "method"}


def norm(s: str) -> str:
    s = s.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    return re.sub(r"\s+", " ", s).strip().lower()


def main() -> None:
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    brief_path, sources_path = sys.argv[1], sys.argv[2]
    base = os.path.dirname(os.path.abspath(sources_path))
    with open(brief_path, encoding="utf-8") as f:
        brief = f.read()
    with open(sources_path, encoding="utf-8") as f:
        sources = json.load(f)

    errors: list[str] = []
    warns: list[str] = []

    # Sources: files exist, timestamps present, declared quotes appear in text.
    texts: dict[str, str] = {}
    for sid, s in sources.items():
        if not re.fullmatch(r"S\d+", sid):
            errors.append(f"source id {sid!r} must look like S1, S2, ...")
        for key in ("url", "fetched_at", "file"):
            if not s.get(key):
                errors.append(f"{sid}: missing {key}")
        try:
            datetime.fromisoformat(str(s.get("fetched_at", "")).replace("Z", "+00:00"))
        except ValueError:
            errors.append(f"{sid}: fetched_at is not an ISO 8601 timestamp")
        path = os.path.join(base, s.get("file", ""))
        try:
            with open(path, encoding="utf-8", errors="ignore") as f:
                texts[sid] = norm(f.read())
        except OSError:
            errors.append(f"{sid}: saved text not found at {s.get('file')}")
            continue
        if len(texts[sid]) < 50:
            errors.append(f"{sid}: saved text is empty or too short to support claims")
        for q in s.get("quotes", []):
            if norm(q) not in texts[sid]:
                errors.append(f"{sid}: declared quote not found in saved text: {q[:60]!r}")

    # Brief: every content line outside exempt sections cites a known source.
    section = ""
    cited: set[str] = set()
    for n, raw in enumerate(brief.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("```"):
            continue
        if line.startswith("#"):
            section = line.lstrip("#").strip().lower()
            continue
        ids = CITE.findall(line)
        cited.update(ids)
        if section in EXEMPT_SECTIONS:
            continue
        if not ids:
            errors.append(f"line {n}: no citation: {line[:70]!r}")
        for sid in ids:
            if sid not in sources:
                errors.append(f"line {n}: cites unknown source {sid}")
        for quote, cites in QUOTE.findall(line):
            qids = CITE.findall(cites)
            if not any(norm(quote) in texts.get(sid, "") for sid in qids):
                errors.append(f"line {n}: quote not found in cited source(s) {qids}: {quote[:60]!r}")

    for sid in sources:
        if sid not in cited:
            warns.append(f"{sid} is listed in sources.json but never cited")

    for w in warns:
        print(f"WARN  {w}")
    for e in errors:
        print(f"ERROR {e}")
    if errors:
        print(f"FAILED: {len(errors)} error(s)")
        sys.exit(1)
    print(f"PASSED: {len(cited & set(sources))} source(s) cited, all quotes verified")


if __name__ == "__main__":
    main()
