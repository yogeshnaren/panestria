# Brief and sources format

## brief.md

```markdown
# <Title>

## Summary
- One-sentence answer to the question. [S1]

## Findings
- Finding with a number and as-of date. [S2]
- "An exact quoted passage from the source." [S3]

## Open questions
- Things that could not be sourced, or sources that disagree.

## Sources
- S1: <title> - <url> (fetched <date>)
```

Rules the checker enforces:

- Every non-empty, non-heading line outside `## Sources`, `## Open questions` and
  `## Method` must contain at least one citation `[S<n>]`.
- Every cited ID must exist in `sources.json`.
- Every quoted passage of 20+ characters followed by a citation must appear in that
  source's saved text (case and whitespace are normalized).
- Every source must have a non-empty saved text file and a `fetched_at` timestamp.
- Every source listed in `sources.json` should be cited (unused sources are warnings).

## sources.json

```json
{
  "S1": {
    "url": "https://example.com/page",
    "title": "Example page",
    "fetched_at": "2026-10-11T09:30:00Z",
    "file": "sources/S1.txt",
    "quotes": ["exact words copied from the saved text"]
  }
}
```

`file` paths are relative to the folder containing `sources.json`.
