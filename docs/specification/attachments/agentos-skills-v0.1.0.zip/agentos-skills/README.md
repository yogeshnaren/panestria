# AgentOS skills

Seven [Agent Skills](https://agentskills.io/specification) for the orchestrator's
first version. Each is a folder with a `SKILL.md` plus small, standard-library-only
scripts, so the same skill works in Claude Code, Codex, Hermes and the local primary
AI.

| Skill | Path it serves | What it does | Script |
| --- | --- | --- | --- |
| `hardware-probe` | Setup | Detects hardware, picks local models and specialist packs, writes the capability manifest | `hwprobe.py` |
| `goal-contract` | Delegate, Build | Turns a request into a contract with machine-checkable acceptance checks | `validate_contract.py` |
| `verified-research-brief` | Delegate | Research briefs whose citations and quotes are checked against saved sources | `verify_citations.py` |
| `claude-code-worker` | Build | Runs Claude Code headlessly on the user's own login with repo config neutralized | `prepare_worktree.py`, `run_worker.py` |
| `egress-preflight` | All cloud jobs | Lists what a cloud agent could read and blocks what policy forbids | `egress_manifest.py` |
| `milestone-handoff` | Long-running work | Feature list, progress log and handoff that keep multi-session work on plan | `check_features.py` |
| `capture-learning` | Every task | Records corrections, facts, routing and memory usage as candidates; never edits memory | `validate_candidates.py` |

## Install

```bash
tools/install_skills.sh --dry-run                 # see what would happen
tools/install_skills.sh --claude --link           # symlink into Claude Code's skills folder
tools/install_skills.sh --codex --hermes          # also copy to Codex and Hermes
```

Skill folder locations differ by tool and version; check them before the first
install. For the orchestrator's dedicated Claude config, set `CLAUDE_CONFIG_DIR`
first. Note that Claude Code's `--safe-mode` and `--bare` profiles don't load
skills from the config folder; the context compiler passes the relevant skill text
instead.

## Test

```bash
pip install skills-ref pyyaml     # spec validator (CLI: agentskills) and YAML support
tools/test_skills.sh
```

`agentskills to-prompt skills/*` prints the `<available_skills>` block the local
primary AI puts in its prompt, so it loads a full `SKILL.md` only when a task
matches.

## Trust rules

- A skill's `allowed-tools` is a request, not a grant: the kernel's policy decides.
- Scripts run inside the task's sandbox, never with the orchestrator's privileges.
- Third-party skills are pinned by hash, scanned and reviewed before use.
- Skills the system learns are proposed as pull requests, tested on replay tasks
  and approved by the user before any agent can use them.

License: Apache-2.0.
