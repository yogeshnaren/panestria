#!/usr/bin/env bash
# Sync the skills in ../skills into each agent harness's skill folder.
# Default target: Claude Code (the orchestrator's dedicated config dir if set).
# Usage: tools/install_skills.sh [--claude] [--codex] [--hermes] [--dir PATH] [--link] [--dry-run]
#   --link     symlink instead of copy (edits in the repo apply immediately)
#   --dry-run  print what would happen
# Skill folder locations differ by tool and version; confirm them before first use.
set -euo pipefail

SRC="$(cd "$(dirname "$0")/../skills" && pwd)"
TARGETS=()
MODE=copy
DRY=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --claude) TARGETS+=("${CLAUDE_CONFIG_DIR:-$HOME/.claude}/skills") ;;
    --codex)  TARGETS+=("${CODEX_HOME:-$HOME/.codex}/skills") ;;
    --hermes) TARGETS+=("$HOME/.hermes/skills") ;;
    --dir)    TARGETS+=("$2"); shift ;;
    --link)   MODE=link ;;
    --dry-run) DRY=1 ;;
    *) echo "unknown option: $1" >&2; exit 1 ;;
  esac
  shift
done
[[ ${#TARGETS[@]} -eq 0 ]] && TARGETS=("${CLAUDE_CONFIG_DIR:-$HOME/.claude}/skills")

run() { if [[ $DRY -eq 1 ]]; then echo "+ $*"; else "$@"; fi; }

for target in "${TARGETS[@]}"; do
  run mkdir -p "$target"
  for skill in "$SRC"/*/; do
    name="$(basename "$skill")"
    dest="$target/$name"
    if [[ -e "$dest" && ! -L "$dest" && $MODE == link ]]; then
      echo "skip $dest (exists and is not a symlink)"; continue
    fi
    run rm -rf "$dest"
    if [[ $MODE == link ]]; then run ln -s "${skill%/}" "$dest"; else run cp -R "${skill%/}" "$dest"; fi
    echo "installed $name -> $dest ($MODE)"
  done
done
