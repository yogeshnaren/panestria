#!/usr/bin/env bash
# Validate every skill against the Agent Skills spec and run each script's self-tests.
# Needs: python3, git; the spec check needs `pip install skills-ref` (CLI: agentskills).
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
S="$ROOT/skills"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
fail=0
ok()  { echo "PASS  $*"; }
bad() { echo "FAIL  $*"; fail=1; }
expect() { local want=$1; shift; "$@" >/dev/null 2>&1; local got=$?; [[ $got -eq $want ]] && ok "$*" || bad "$* (exit $got, want $want)"; }

if command -v agentskills >/dev/null; then
  for d in "$S"/*/; do expect 0 agentskills validate "$d"; done
else
  echo "SKIP  spec validation (pip install skills-ref)"
fi

# hardware-probe
expect 0 python3 "$S/hardware-probe/scripts/hwprobe.py" --preset omen-8gb --want coding,tts

# goal-contract (YAML needs PyYAML; use JSON here)
python3 - "$S" "$TMP" <<'EOF'
import json, sys
s, t = sys.argv[1], sys.argv[2]
c = {"id": "goal-001", "version": 1, "intent": "Add retry", "privacy_class": "internal",
     "constraints": {"allowed_paths": ["src/**"], "forbidden_paths": [".env*"], "outbound_network": False},
     "budget": {"api_usd_max": 1, "max_attempts_per_task": 2, "wall_clock_minutes_max": 30},
     "acceptance": [{"id": "t", "description": "tests", "check": {"type": "command", "run": "pytest"}}],
     "non_goals": ["deps"]}
json.dump(c, open(f"{t}/good.json", "w"))
c["privacy_class"] = "restricted"; c["constraints"]["outbound_network"] = True
json.dump(c, open(f"{t}/bad.json", "w"))
EOF
expect 0 python3 "$S/goal-contract/scripts/validate_contract.py" "$TMP/good.json"
expect 1 python3 "$S/goal-contract/scripts/validate_contract.py" "$TMP/bad.json"

# verified-research-brief
EX="$S/verified-research-brief/assets/example"
expect 0 python3 "$S/verified-research-brief/scripts/verify_citations.py" "$EX/brief.md" "$EX/sources.json"
sed 's/must match the parent directory name/must equal any name/' "$EX/brief.md" > "$EX/.bad.md"
expect 1 python3 "$S/verified-research-brief/scripts/verify_citations.py" "$EX/.bad.md" "$EX/sources.json"
rm -f "$EX/.bad.md"

# claude-code-worker
mkdir -p "$TMP/wt/.claude" && echo '{}' > "$TMP/wt/.claude/settings.json" && echo '{}' > "$TMP/wt/.mcp.json"
expect 3 python3 "$S/claude-code-worker/scripts/prepare_worktree.py" "$TMP/wt"
expect 0 python3 "$S/claude-code-worker/scripts/prepare_worktree.py" "$TMP/wt" --apply
ln -s /etc/hosts "$TMP/wt/escape"
expect 2 python3 "$S/claude-code-worker/scripts/prepare_worktree.py" "$TMP/wt"
echo "task" > "$TMP/task.md"
expect 0 python3 "$S/claude-code-worker/scripts/run_worker.py" --worktree "$TMP/wt" --prompt-file "$TMP/task.md" --dry-run

# egress-preflight
P="$S/egress-preflight/assets/egress-policy.example.json"
mkdir -p "$TMP/ws/src" && echo "x = 1" > "$TMP/ws/src/a.py"
expect 0 python3 "$S/egress-preflight/scripts/egress_manifest.py" "$TMP/ws" --policy "$P" --class internal --dest anthropic
printf 'TOKEN = "abcdefghijklmnop1234"\n' > "$TMP/ws/src/b.py"
expect 1 python3 "$S/egress-preflight/scripts/egress_manifest.py" "$TMP/ws" --policy "$P" --class internal --dest anthropic
expect 1 python3 "$S/egress-preflight/scripts/egress_manifest.py" "$TMP/ws" --policy "$P" --class restricted --dest openai

# milestone-handoff
F="$S/milestone-handoff/assets/features.template.json"
python3 - "$F" "$TMP" <<'EOF'
import json, sys
d = json.load(open(sys.argv[1])); t = sys.argv[2]
d["features"][0]["passes"] = True; json.dump(d, open(f"{t}/noev.json", "w"))
d["features"][0]["evidence"] = "3 passed"; json.dump(d, open(f"{t}/ok.json", "w"))
EOF
expect 1 python3 "$S/milestone-handoff/scripts/check_features.py" "$F" "$TMP/noev.json"
expect 0 python3 "$S/milestone-handoff/scripts/check_features.py" "$F" "$TMP/ok.json"

# capture-learning
expect 0 python3 "$S/capture-learning/scripts/validate_candidates.py" "$S/capture-learning/assets/candidate.examples.jsonl"
echo '{"type":"fact"}' > "$TMP/bad.jsonl"
expect 1 python3 "$S/capture-learning/scripts/validate_candidates.py" "$TMP/bad.jsonl"

[[ $fail -eq 0 ]] && echo "ALL PASSED" || { echo "SOME TESTS FAILED"; exit 1; }
